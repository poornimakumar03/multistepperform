import { useState } from "react";
import "./FormInput.css";
const FormInput=(props)=>{
    const[focused,setfocused]=useState(false);
        const{label, errormessage, onChange, id,...inputprops }=props;
        const handleFocus=(e)=>{
            setfocused(true);
        }
        return(
            <div className="FormInput">
                <label>{label}</label>
                <input{...inputprops}
               onChange={onChange} 
               onBlur={handleFocus}
               onFocus={()=>inputprops.name==="password"&&setfocused(true)}
               focused={focused.toString()}
               />
            </div>
        );
};
export default FormInput;