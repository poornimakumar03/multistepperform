import React from "react";
import { useState } from "react";
import FormInput from "./FormInput";
import "./Step";
import "./App.css";
const App=()=>{
  const[values,setvalues]=useState(
    {
    username:"",
    email:"",
    Birthday:"",
    password:""});
    const input=[
      {
        id:1,
        name:"username",
        type:"text",
        placeholder:"username",
        errormessage:"username should be 3-16 character and shouldn't include any special character",
        label:"username",
        required:true,
      },
    {
      id:2,
      name:"email",
      type:"text",
      placeholder:"email",
      errormessage:"it should a valid email address",
      label:"email",
      required:true,
    },
      {
        id:3,
        name:"birthday",
        type:"date",
        placeholder:"enter your date",
        label:"birthday"},
        {
          id:4,
          name:"password",
          type:"password",
          placeholder:"password",
          errormessage:"password must be 8-20 characters and include at least 1 letter,1 number and 1 special character",
          label:"password",
          required:true,
        }
      ]
      const handlesumbit=(e)=>{
        e.preventDefault();
      };
      const onChange=(e)=>{
        setvalues({...values,[e.target.name]:e.target.value});};
        return(
          <div className="app">
            <form onSubmit={handlesumbit}>
              <h1>Become An Advertiser </h1>
              <p>personal details</p>
              {input.map((input)=>(
                <FormInput key={input.id}{...input}value={values[input.name]}onChange={onChange}/>))}
                <button>next</button>
            </form>
          </div>
        );
      };
export default App;
